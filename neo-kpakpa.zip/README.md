# Neo-KpaKpa Livraison (MVP)
Repo minimal pour le SaaS Neo-KpaKpa Livraison — backend Node/TS, frontend Next.js, mobile Flutter prototype.
## Démarrage local (prérequis)
- Docker & Docker Compose
- Node.js (pour dev local optional)
- Flutter SDK (pour mobile)
## Commandes rapides
1. `docker-compose up --build`
2. Exécuter migrations sur la DB Postgres (PostGIS)
3. `cd services/api && npm ci && npm run dev`
4. `cd apps/web-next && npm ci && npm run dev`
5. Ouvrir `http://localhost:3000`
