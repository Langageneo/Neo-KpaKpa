import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

const apiBase = "http://10.0.2.2:8080";

void main()=>runApp(MaterialApp(home: KpakpaApp()));

class KpakpaApp extends StatefulWidget{
  @override State<KpakpaApp> createState()=>_KpakpaState();
}

class _KpakpaState extends State<KpakpaApp>{
  bool delivering=false;
  String message="";

  Future<void> deliver() async{
    setState(()=>delivering=true);
    final pos = await Geolocator.getCurrentPosition();
    final img = await ImagePicker().pickImage(source: ImageSource.camera);
    if(img==null) return;
    final bytes=base64Encode(await img.readAsBytes());
    final r=await http.post(Uri.parse("$apiBase/api/scan/verify"),
      headers:{"Content-Type":"application/json"},
      body:jsonEncode({
        "token":"test-token",
        "courier_id":"test-courier",
        "gps":{"lat":pos.latitude,"lon":pos.longitude},
        "selfieBase64":bytes
      }));
    setState(()=>{delivering=false; message=r.body;});
  }

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(title:Text("Neo-KpaKpa Livraison")),
      body:Center(
        child: delivering
          ? CircularProgressIndicator()
          : ElevatedButton(
              onPressed:deliver,
              child:Text("📦 Scanner et Livrer"))
      ),
      bottomNavigationBar: Padding(
        padding:EdgeInsets.all(8),
        child:Text(message,textAlign:TextAlign.center),
      ),
    );
  }
}
