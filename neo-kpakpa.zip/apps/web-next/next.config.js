module.exports = {
  reactStrictMode: true,
  experimental: { appDir: false }
};
