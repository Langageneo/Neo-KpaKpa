import { useEffect, useState } from "react";
export default function Dashboard() {
  const [locations, setLocations] = useState([]);
  useEffect(() => {
    const evtSource = new EventSource("/api/track/sse/locations");
    evtSource.onmessage = (e) => {
      try { setLocations(JSON.parse(e.data)); } catch {}
    };
    return () => evtSource.close();
  }, []);
  return (
    <div style={{padding:20}}>
      <h2>Positions récentes (live)</h2>
      <ul>
        {locations.map((l,i)=> <li key={i}>{l.courier_id} — {l.lat},{l.lon} — {l.recorded_at}</li>)}
      </ul>
    </div>
  )
}
