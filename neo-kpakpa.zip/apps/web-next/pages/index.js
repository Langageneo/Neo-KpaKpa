import Link from "next/link";
export default function Home() {
  return (
    <div style={{padding:20}}>
      <h1>🚚 Neo-KpaKpa Livraison</h1>
      <p>Prototype admin / marketing</p>
      <Link href="/dashboard">Voir dashboard</Link>
    </div>
  );
}
