#!/usr/bin/env bash
API=${API_URL:-http://localhost:8080}
TOKEN="SAMPLE-TOKEN-123"
COURIER="courier-1"
curl -s -X POST $API/api/scan/verify -H "Content-Type: application/json" -d '{
  "token":"'"$TOKEN"'",
  "courier_id":"'"$COURIER"'",
  "gps":{"lat":6.0,"lon":-5.0,"accuracy":5},
  "selfieBase64":"FAKE_BASE64_SELFIE"
}' | jq
