import QRCode from "qrcode";
export async function generateQrDataUrl(token:string) {
  const url = `neo-kpakpa://scan?token=${token}`;
  return QRCode.toDataURL(url);
}
