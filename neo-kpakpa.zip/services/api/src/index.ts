import express from "express";
import bodyParser from "body-parser";
import { Pool } from "pg";
import dotenv from "dotenv";
import authRouter from "./routes/auth";
import ordersRouter from "./routes/orders";
import scanRouter from "./routes/scan";
import courierRouter from "./routes/courier";
import syncRouter from "./routes/sync";
import trackRouter from "./routes/track";

dotenv.config();
const PORT = process.env.PORT || 8080;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const app = express();
app.use(bodyParser.json());
app.use((req:any,res,next)=>{ req.db = pool; next(); });

app.use("/api/auth", authRouter);
app.use("/api/orders", ordersRouter);
app.use("/api/scan", scanRouter);
app.use("/api/courier", courierRouter);
app.use("/api/sync", syncRouter);
app.use("/api/track", trackRouter);
app.get("/health", (_req,res)=>res.json({status:"ok"}));
app.listen(PORT, ()=>console.log(`Neo-KpaKpa API listening ${PORT}`));
