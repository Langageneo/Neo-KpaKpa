import { Router } from "express";
import axios from "axios";

const router = Router();

router.post("/verify", async (req:any, res) => {
  const { token, courier_id, gps, selfieBase64 } = req.body;
  if (!token || !courier_id || !gps) return res.status(400).json({ success:false, reason: "missing_params" });

  const pool = req.db;
  const q = await pool.query("SELECT * FROM qr_tokens WHERE token=$1 AND expires_at > now()", [token]);
  if (!q.rows.length) return res.status(400).json({ success:false, reason: "invalid_token" });
  const orderId = q.rows[0].order_id;

  const geoRes = await pool.query(
    `SELECT ST_DistanceSphere(dropoff_location, ST_SetSRID(ST_MakePoint($1,$2),4326)) as distance_m
     FROM orders WHERE id = $3`,
    [gps.lon, gps.lat, orderId]
  );
  if (!geoRes.rows.length) return res.status(400).json({ success:false, reason:'order_not_found' });
  const distanceM = parseFloat(geoRes.rows[0].distance_m);
  const DISTANCE_THRESHOLD = Number(process.env.DELIVERY_DISTANCE_THRESHOLD || 50);
  if (distanceM > DISTANCE_THRESHOLD) {
    await pool.query(
      `INSERT INTO courier_locations (courier_id, order_id, location, accuracy_m)
       VALUES ($1,$2, ST_SetSRID(ST_MakePoint($3,$4),4326), $5)`,
      [courier_id, orderId, gps.lon, gps.lat, gps.accuracy || null]
    );
    return res.status(400).json({ success:false, reason: "out_of_geofence", distance: distanceM });
  }

  try {
    const faceRes = await axios.post(process.env.FACEIO_ENDPOINT || "https://faceio.example/verify", {
      apiKey: process.env.FACEIO_API_KEY,
      selfie: selfieBase64,
      referenceId: orderId
    }, { timeout: 10000 });

    if (!faceRes.data || !faceRes.data.match) {
      await pool.query(
        `INSERT INTO courier_locations (courier_id, order_id, location, accuracy_m)
         VALUES ($1,$2, ST_SetSRID(ST_MakePoint($3,$4),4326), $5)`,
        [courier_id, orderId, gps.lon, gps.lat, gps.accuracy || null]
      );
      return res.status(400).json({ success:false, reason:'face_mismatch' });
    }
  } catch (err:any) {
    return res.status(500).json({ success:false, reason:'face_api_error', details: err?.message });
  }

  await pool.query("UPDATE orders SET status='delivered', courier_id=$1 WHERE id=$2", [courier_id, orderId]);
  await pool.query(
    `INSERT INTO courier_locations (courier_id, order_id, location, accuracy_m)
     VALUES ($1,$2, ST_SetSRID(ST_MakePoint($3,$4),4326), $5)`,
    [courier_id, orderId, gps.lon, gps.lat, gps.accuracy || null]
  );

  res.json({ success:true, orderId, distance: distanceM });
});

export default router;
