import { Router } from "express";
const router = Router();

router.post("/batch", async (req:any, res) => {
  const { events } = req.body;
  if (!events || !Array.isArray(events)) return res.status(400).json({ error: "missing_events" });
  const pool = req.db;
  const accepted: string[] = [];
  for (const ev of events) {
    try {
      if (ev.type === "scan") {
        const { token, courier_id, gps } = ev.payload;
        const tokenRow = (await pool.query("SELECT order_id FROM qr_tokens WHERE token=$1 AND expires_at>now()", [token])).rows[0];
        if (tokenRow) {
          const orderId = tokenRow.order_id;
          await pool.query("UPDATE orders SET status='delivered', courier_id=$1 WHERE id=$2", [courier_id, orderId]);
          await pool.query("INSERT INTO courier_locations (courier_id, order_id, location) VALUES ($1,$2, ST_SetSRID(ST_MakePoint($3,$4),4326))", [courier_id, orderId, gps.lon, gps.lat]);
          accepted.push(ev._id);
        }
      } else if (ev.type === "courier_location") {
        await pool.query("INSERT INTO courier_locations (courier_id, order_id, location) VALUES ($1,$2, ST_SetSRID(ST_MakePoint($3,$4),4326))", [ev.courier_id, ev.order_id || null, ev.lon, ev.lat]);
        accepted.push(ev._id);
      }
    } catch (e) { /* continue */ }
  }
  res.json({ accepted });
});

export default router;
