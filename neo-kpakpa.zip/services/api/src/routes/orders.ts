import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { generateQrDataUrl } from "../utils/qr";

const router = Router();

router.post("/", async (req:any, res) => {
  const { client_id, pickup, dropoff, tenant_id } = req.body;
  if (!client_id || !pickup || !dropoff) return res.status(400).json({ error: "missing" });
  const pool = req.db;
  const id = uuidv4();
  await pool.query(
    `INSERT INTO orders (id, tenant_id, client_id, status, pickup_location, dropoff_location, created_at)
     VALUES ($1,$2,$3,$4, ST_SetSRID(ST_MakePoint($5,$6),4326), ST_SetSRID(ST_MakePoint($7,$8),4326), now())`,
    [id, tenant_id || null, client_id, 'pending', pickup.lon, pickup.lat, dropoff.lon, dropoff.lat]
  );
  const token = uuidv4();
  await pool.query("INSERT INTO qr_tokens (id, order_id, token, expires_at) VALUES ($1,$2,$3, now() + interval '2 days')", [uuidv4(), id, token]);
  const qr = await generateQrDataUrl(token);
  res.json({ id, token, qr });
});

router.get("/:id", async (req:any, res) => {
  const pool = req.db;
  const r = await pool.query("SELECT * FROM orders WHERE id=$1", [req.params.id]);
  if (!r.rows.length) return res.status(404).json({ error: "not found" });
  res.json(r.rows[0]);
});

export default router;
