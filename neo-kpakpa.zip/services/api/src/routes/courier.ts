import { Router } from "express";
import { v4 as uuidv4 } from "uuid";

const router = Router();

router.post("/location", async (req:any, res) => {
  const { courier_id, order_id, lat, lon, accuracy } = req.body;
  if (!courier_id || !lat || !lon) return res.status(400).json({ error: "missing" });
  const pool = req.db;
  const id = uuidv4();
  await pool.query(
    `INSERT INTO courier_locations (id, courier_id, order_id, location, accuracy_m) VALUES ($1,$2,$3, ST_SetSRID(ST_MakePoint($4,$5),4326), $6)`,
    [id, courier_id, order_id || null, lon, lat, accuracy || null]
  );
  await pool.query(
    `UPDATE users SET last_location = ST_SetSRID(ST_MakePoint($1,$2),4326) WHERE id=$3`,
    [lon, lat, courier_id]
  ).catch(()=>{});
  res.json({ success: true, id });
});

export default router;
