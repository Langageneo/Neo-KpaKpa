import { Router } from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";

const router = Router();

router.post("/signup", async (req:any, res) => {
  const { email, phone, role, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: "missing fields" });
  const pool = req.db;
  const id = uuidv4();
  const hash = await bcrypt.hash(password, 10);
  await pool.query("INSERT INTO users (id,email,phone,role) VALUES ($1,$2,$3,$4)", [id,email,phone,role||'client']);
  await pool.query("CREATE TABLE IF NOT EXISTS auth (user_id uuid PRIMARY KEY, password text)");
  await pool.query("INSERT INTO auth (user_id,password) VALUES ($1,$2) ON CONFLICT (user_id) DO UPDATE SET password=EXCLUDED.password", [id,hash]);
  const token = jwt.sign({ id, role }, process.env.JWT_SECRET || "changeme", { expiresIn: "30d" });
  res.json({ id, token });
});

router.post("/login", async (req:any, res) => {
  const { email, password } = req.body;
  const pool = req.db;
  const r = await pool.query("SELECT id FROM users WHERE email=$1", [email]);
  if (!r.rows.length) return res.status(404).json({ error: "not found" });
  const userId = r.rows[0].id;
  const auth = (await pool.query("SELECT password FROM auth WHERE user_id=$1", [userId])).rows[0];
  if (!auth) return res.status(401).json({ error: "no auth" });
  const ok = await bcrypt.compare(password, auth.password);
  if (!ok) return res.status(401).json({ error: "invalid" });
  const token = jwt.sign({ id: userId }, process.env.JWT_SECRET || "changeme", { expiresIn: "30d" });
  res.json({ id: userId, token });
});

export default router;
