import { Router } from "express";
const router = Router();

router.get("/sse/locations", async (req:any, res) => {
  res.writeHead(200, {
    Connection: "keep-alive",
    "Content-Type": "text/event-stream",
    "Cache-Control": "no-cache"
  });

  const pool = req.db;
  const sendLatest = async () => {
    const r = await pool.query(`SELECT courier_id, ST_X(location) as lon, ST_Y(location) as lat, recorded_at FROM courier_locations ORDER BY recorded_at DESC LIMIT 100`);
    res.write(`data: ${JSON.stringify(r.rows)}\n\n`);
  };

  await sendLatest();
  const interval = setInterval(sendLatest, 3000);
  req.on("close", () => clearInterval(interval));
});

export default router;
