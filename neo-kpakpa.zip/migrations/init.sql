CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE,
  phone text,
  role text,
  created_at timestamptz DEFAULT now(),
  last_location geometry(Point,4326)
);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid,
  client_id uuid REFERENCES users(id),
  courier_id uuid REFERENCES users(id),
  status text,
  pickup_location geometry(Point,4326),
  dropoff_location geometry(Point,4326),
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS qr_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid REFERENCES orders(id),
  token text UNIQUE,
  expires_at timestamptz
);

CREATE TABLE IF NOT EXISTS courier_locations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  courier_id uuid NOT NULL,
  order_id uuid NULL,
  location geometry(Point,4326) NOT NULL,
  accuracy_m numeric NULL,
  recorded_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_courier_locations_geom ON courier_locations USING GIST (location);
CREATE INDEX IF NOT EXISTS idx_users_last_location ON users USING GIST (last_location);
